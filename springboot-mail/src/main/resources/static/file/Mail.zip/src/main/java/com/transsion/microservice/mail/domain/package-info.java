/**
 * JPA domain objects.
 */
package com.transsion.microservice.mail.domain;
