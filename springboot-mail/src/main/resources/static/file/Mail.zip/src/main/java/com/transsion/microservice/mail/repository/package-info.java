/**
 * Spring Data JPA repositories.
 */
package com.transsion.microservice.mail.repository;
