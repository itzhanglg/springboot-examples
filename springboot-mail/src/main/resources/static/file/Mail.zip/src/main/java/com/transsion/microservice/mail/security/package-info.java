/**
 * Spring Security configuration.
 */
package com.transsion.microservice.mail.security;
