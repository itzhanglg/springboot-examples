/**
 * Audit specific code.
 */
package com.transsion.microservice.mail.config.audit;
