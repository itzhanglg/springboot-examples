/**
 * Spring MVC REST controllers.
 */
package com.transsion.microservice.mail.web.rest;
