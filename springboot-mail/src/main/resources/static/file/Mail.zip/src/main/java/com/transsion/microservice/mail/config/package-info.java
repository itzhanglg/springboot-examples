/**
 * Spring Framework configuration files.
 */
package com.transsion.microservice.mail.config;
