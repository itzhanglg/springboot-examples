/**
 * View Models used by Spring MVC REST controllers.
 */
package com.transsion.microservice.mail.web.rest.vm;
