/**
 * Service layer beans.
 */
package com.transsion.microservice.mail.service;
